rootProject.name = "residential-sector-api"
plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "0.8.0"
}